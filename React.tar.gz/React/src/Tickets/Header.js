import React from 'react'

const Header = () => {
    return (
        <header>
            <div>LOGO</div>
            <div>MENÚ DE TOTES LES APPS</div>
            <div>USER</div>
        </header>
    )
}

export default Header;