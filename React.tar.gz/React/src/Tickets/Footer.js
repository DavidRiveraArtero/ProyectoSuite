import React from 'react'

const Footer = () => {
  return (
    <footer>
        <div>FOOTER</div>
    </footer>
  )
}

export default Footer;
