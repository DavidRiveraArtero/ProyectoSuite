class users_messages {

    constructor (message, group_id, created)
    {
        this.message=message;
        this.group_id=group_id;    
        this.created=created;          
    }

}
