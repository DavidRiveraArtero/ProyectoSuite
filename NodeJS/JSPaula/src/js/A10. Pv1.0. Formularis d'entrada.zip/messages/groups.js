class groups {

    constructor (id, name, parent_id)
    {
        this.message=message;
        this.user_id=user_id;    
        this.created=created;          

    }


}
