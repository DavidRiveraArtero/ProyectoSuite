export class Messages{

    constructor (id,author_id,message,created, privpub, desti)
    {
        this.id=id;
        this.author_id=author_id;
        this.message=message;
        this.created=created;     
        this.privpub=privpub;     
        this.desti=desti;     
    }
       
}