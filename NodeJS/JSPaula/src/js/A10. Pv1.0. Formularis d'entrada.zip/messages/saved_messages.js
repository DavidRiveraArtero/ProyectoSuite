class saved_messages {

    constructor (message,user_id)
    {
        this.message=message;
        this.user_id=user_id;          
    }



}