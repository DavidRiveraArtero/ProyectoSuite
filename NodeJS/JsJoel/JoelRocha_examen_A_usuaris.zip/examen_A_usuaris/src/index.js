import './styles.css'

var dadesusuaris = fetch("https://examenm06-ee14f-default-rtdb.firebaseio.com/usuaris.json")
.then(data => data.json())  
.then(tot => {
    // const myArrClean = tot.filter(Boolean);
    tot = tot.filter(Boolean);
    crearFormulariHtml(tot);
})

function crearFormulariHtml(llistadeusuaris)
{
    console.log(llistadeusuaris);
    var taulaTitols = `
        <tr class="fila" id="fila">
            <th colspan="1">ID</th>
            <th colspan="1">NOM</th>
            <th colspan="1">CONTRASENYA</th>
            <th colspan="1">BORRAR</th>
        </tr>
    `
    llistadeusuaris.forEach((v,i,array) => {
        taulaTitols += `
            <tr>
                <td>${v.id}</td>
                <td>${v.nom}</td>
                <td>${v.password}</td>
                <td>
                    <button class="brosa" id="brosa">Esborra</button>
                </td>
            </tr>
        `
    });

    var taula = document.getElementById("taula");
    taula.innerHTML=taulaTitols;

    // BORRAR USUARI
    var agenda = taula.parentElement;
    agenda.addEventListener("click", event=>{
        event.preventDefault();
        console.log("ENTRO")
        // SI FEM CLICK A LA ICONA BROSA
        if(event.target){
            event.target.parentNode.parentNode.remove();
            var id = event.target.parentNode.parentNode.firstElementChild.innerHTML;

            // BORRAR EN FIREBASE
            delUsuari(id);
        }
    });

    // AFEGIR USUARI
    var cont = 4;
    var enviar = document.getElementById("envia");
    enviar.addEventListener("click",event =>{
        event.preventDefault();

        // CREEM NOU USUARI
        var id = cont;
        var nom = document.getElementById("nom");
        var password = document.getElementById("password");
        if(password.value.length >=8){
            nom = nom.value;
            password = password.value;

            // PRIMERA MANERA
            var usuari = {id: id, nom: nom, password: password}

            // SEGONA MANERA
            // usuari.id=
            // usuari.nom=
            // usuari.passweord


            // AFEGIR A ARRAY
            llistadeusuaris.push(usuari);

            // AFEGIR A FIREBASE
            setUsuari(usuari,id);
            cont++;
        }
        else{
            alert("Contrasenya curta, ha de ser de 8 caràcters mínim");
            console.log("Contrasenya curta, ha de ser de 8 caràcters mínim");
        } 
        nom.autofocus;
    });

    // var reset = document.getElementById("ole");
    // reset.addEventListener("click",event=>{
    //     reset.preventDefault();
    //     var nom = document.getElementById("nom");
    //     nom.autofocus;
    // });

}

async function setUsuari(usuari,id) {
    try {
        const res= await fetch('https://examenm06-ee14f-default-rtdb.firebaseio.com/usuaris/'+id+'.json',
        {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(usuari)
        })
    }
    catch (error){
        console.log(error)
    }
}

async function delUsuari(id){
    try {
        const res= await fetch('https://examenm06-ee14f-default-rtdb.firebaseio.com/usuaris/'+id+'.json',
        {
            method: 'DELETE',
        })
    }
    catch (error){
        console.log(error)
    }
}
